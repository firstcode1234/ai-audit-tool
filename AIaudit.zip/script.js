async function submitForm(event) {
    event.preventDefault(); // 폼 제출 기본 동작 방지

    const userInput = document.getElementById("user_input").value; // 사용자가 입력한 데이터 가져오기

    try {
        // Replit Flask 백엔드 URL에 POST 요청 보내기
        const response = await fetch("https://15707527-5ca4-4c9b-add1-48ef7427084b-00-bcxj9f1yro94.pike.replit.dev/generate", { // 정확한 백엔드 엔드포인트
            method: "POST",
            headers: {
                "Content-Type": "application/json" // JSON 데이터 전송
            },
            body: JSON.stringify({ user_input: userInput }) // 사용자의 입력 데이터
        });

        const data = await response.json(); // JSON 응답 처리

        if (response.ok) {
            // 성공적으로 결과를 받아온 경우, 결과를 HTML에 표시
            document.getElementById("sample_content").textContent = data.sample_content;
            document.getElementById("generated_content").textContent = data.generated_content;
        } else {
            // 오류 발생 시 경고창 표시
            alert(data.error || "서버 오류가 발생했습니다.");
        }
    } catch (error) {
        // 네트워크 오류 처리
        alert(`네트워크 오류: ${error.message}`);
    }
}

// 폼 제출 이벤트에 핸들러 연결
document.getElementById("inputForm").addEventListener("submit", submitForm);
