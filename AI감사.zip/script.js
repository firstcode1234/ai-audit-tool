async function submitForm(event) {
    event.preventDefault();

    const userInput = document.getElementById("user_input").value;

    const response = await fetch("https://your-replit-url-here/generate", { // Replit 백엔드 URL
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ user_input: userInput })
    });

    const data = await response.json();
    if (response.ok) {
        document.getElementById("sample_content").textContent = data.sample_content;
        document.getElementById("generated_content").textContent = data.generated_content;
    } else {
        alert(data.error || "오류가 발생했습니다.");
    }
}

document.getElementById("inputForm").addEventListener("submit", submitForm);
